import React from 'react';
import '../styles/TitleComponent.css';

function TitleComponent() {
    return (
        <div className="title-container">
            <div className="title-text">
                {/* <span className="title-main">A GRANDE</span>
                <span className="title-sub">DESCOBERTA</span> */}
            </div>
        </div>
    );
}

export default TitleComponent;
